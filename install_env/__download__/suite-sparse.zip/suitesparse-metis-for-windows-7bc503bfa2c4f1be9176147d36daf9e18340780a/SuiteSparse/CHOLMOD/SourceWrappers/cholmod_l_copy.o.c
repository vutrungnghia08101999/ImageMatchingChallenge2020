#define DLONG
#include <../Core/cholmod_copy.c>
