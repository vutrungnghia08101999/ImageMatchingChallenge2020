#define DLONG
#include <../Cholesky/cholmod_rcond.c>
