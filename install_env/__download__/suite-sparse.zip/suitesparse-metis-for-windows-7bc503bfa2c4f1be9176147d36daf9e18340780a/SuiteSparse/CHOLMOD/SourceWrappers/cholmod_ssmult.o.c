#include <../MatrixOps/cholmod_ssmult.c>
