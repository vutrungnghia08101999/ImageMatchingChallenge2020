#define DLONG
#include <../Modify/cholmod_rowdel.c>
