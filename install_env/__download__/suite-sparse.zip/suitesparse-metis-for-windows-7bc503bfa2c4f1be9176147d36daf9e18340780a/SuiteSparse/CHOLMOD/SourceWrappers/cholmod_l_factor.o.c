#define DLONG
#include <../Core/cholmod_factor.c>
