#define DLONG
#include <../Cholesky/cholmod_amd.c>
