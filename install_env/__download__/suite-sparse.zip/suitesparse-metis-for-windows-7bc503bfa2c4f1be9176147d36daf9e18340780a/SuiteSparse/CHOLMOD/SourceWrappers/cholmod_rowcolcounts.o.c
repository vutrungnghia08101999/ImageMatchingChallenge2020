#include <../Cholesky/cholmod_rowcolcounts.c>
