#define DLONG
#include <../MatrixOps/cholmod_ssmult.c>
