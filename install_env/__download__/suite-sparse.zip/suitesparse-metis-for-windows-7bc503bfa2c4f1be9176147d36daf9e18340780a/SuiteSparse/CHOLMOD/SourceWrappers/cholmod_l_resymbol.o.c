#define DLONG
#include <../Cholesky/cholmod_resymbol.c>
