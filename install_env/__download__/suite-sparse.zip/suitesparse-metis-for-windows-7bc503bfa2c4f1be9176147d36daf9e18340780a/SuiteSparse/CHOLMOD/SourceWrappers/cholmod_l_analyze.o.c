#define DLONG
#include <../Cholesky/cholmod_analyze.c>
