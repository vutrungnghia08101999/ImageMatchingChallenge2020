#include <../MatrixOps/cholmod_scale.c>
