#define DLONG
#include <../Core/cholmod_triplet.c>
