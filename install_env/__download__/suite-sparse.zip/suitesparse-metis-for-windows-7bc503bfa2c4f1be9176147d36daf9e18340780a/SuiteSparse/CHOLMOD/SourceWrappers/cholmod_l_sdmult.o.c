#define DLONG
#include <../MatrixOps/cholmod_sdmult.c>
