#define DLONG
#include <../Core/cholmod_common.c>
