#include <../MatrixOps/cholmod_symmetry.c>
