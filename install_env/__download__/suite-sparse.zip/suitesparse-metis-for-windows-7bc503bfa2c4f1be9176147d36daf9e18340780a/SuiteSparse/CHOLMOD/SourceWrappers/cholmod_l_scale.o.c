#define DLONG
#include <../MatrixOps/cholmod_scale.c>
