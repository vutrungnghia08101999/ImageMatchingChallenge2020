#define DLONG
#include <../Cholesky/cholmod_spsolve.c>
