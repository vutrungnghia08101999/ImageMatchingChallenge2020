#define DLONG
#include <../Core/cholmod_error.c>
