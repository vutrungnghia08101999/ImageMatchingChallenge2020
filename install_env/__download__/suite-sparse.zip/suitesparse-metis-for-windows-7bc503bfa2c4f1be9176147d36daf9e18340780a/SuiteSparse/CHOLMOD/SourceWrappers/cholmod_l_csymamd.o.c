#define DLONG
#include <../Partition/cholmod_csymamd.c>
