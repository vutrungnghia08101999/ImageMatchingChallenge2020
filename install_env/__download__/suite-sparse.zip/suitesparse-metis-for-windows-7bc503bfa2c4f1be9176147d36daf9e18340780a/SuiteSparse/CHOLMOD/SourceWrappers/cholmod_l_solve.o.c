#define DLONG
#include <../Cholesky/cholmod_solve.c>
