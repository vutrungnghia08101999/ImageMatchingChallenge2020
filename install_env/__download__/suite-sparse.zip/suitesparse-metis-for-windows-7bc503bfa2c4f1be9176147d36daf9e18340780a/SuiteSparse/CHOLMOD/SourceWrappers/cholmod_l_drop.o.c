#define DLONG
#include <../MatrixOps/cholmod_drop.c>
