#define DLONG
#include <../Check/cholmod_read.c>
