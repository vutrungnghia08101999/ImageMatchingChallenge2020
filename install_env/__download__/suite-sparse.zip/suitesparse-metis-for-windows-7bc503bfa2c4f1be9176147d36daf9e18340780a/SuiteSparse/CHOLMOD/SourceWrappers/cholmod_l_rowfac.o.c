#define DLONG
#include <../Cholesky/cholmod_rowfac.c>
