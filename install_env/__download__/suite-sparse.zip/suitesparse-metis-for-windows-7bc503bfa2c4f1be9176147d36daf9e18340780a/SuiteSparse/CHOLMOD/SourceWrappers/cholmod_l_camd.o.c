#define DLONG
#include <../Partition/cholmod_camd.c>
