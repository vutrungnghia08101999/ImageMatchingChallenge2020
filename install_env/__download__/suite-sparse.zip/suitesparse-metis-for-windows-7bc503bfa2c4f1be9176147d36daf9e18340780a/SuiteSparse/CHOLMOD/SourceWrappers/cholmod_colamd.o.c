#include <../Cholesky/cholmod_colamd.c>
