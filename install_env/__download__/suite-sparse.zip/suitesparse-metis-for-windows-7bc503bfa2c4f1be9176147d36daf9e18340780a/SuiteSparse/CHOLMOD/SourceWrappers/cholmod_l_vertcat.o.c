#define DLONG
#include <../MatrixOps/cholmod_vertcat.c>
