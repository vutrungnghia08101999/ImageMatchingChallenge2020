#define DLONG
#include <../Cholesky/cholmod_rowcolcounts.c>
