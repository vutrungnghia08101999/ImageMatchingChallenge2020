#define DLONG
#include <../Core/cholmod_memory.c>
