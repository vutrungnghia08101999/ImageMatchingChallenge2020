#define DLONG
#include <../MatrixOps/cholmod_horzcat.c>
