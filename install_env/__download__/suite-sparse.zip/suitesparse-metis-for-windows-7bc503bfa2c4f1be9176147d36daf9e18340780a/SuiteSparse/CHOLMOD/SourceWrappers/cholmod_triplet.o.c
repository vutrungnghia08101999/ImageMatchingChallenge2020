#include <../Core/cholmod_triplet.c>
