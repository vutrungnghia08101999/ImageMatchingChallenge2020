#define DLONG
#include <../Core/cholmod_aat.c>
