#define DLONG
#include <../Partition/cholmod_ccolamd.c>
