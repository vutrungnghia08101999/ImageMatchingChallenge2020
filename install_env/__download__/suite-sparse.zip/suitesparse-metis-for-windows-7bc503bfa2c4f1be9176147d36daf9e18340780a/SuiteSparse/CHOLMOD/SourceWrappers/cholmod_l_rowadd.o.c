#define DLONG
#include <../Modify/cholmod_rowadd.c>
