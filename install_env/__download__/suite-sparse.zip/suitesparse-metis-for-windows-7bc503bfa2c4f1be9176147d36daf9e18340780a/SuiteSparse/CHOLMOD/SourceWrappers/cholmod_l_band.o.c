#define DLONG
#include <../Core/cholmod_band.c>
