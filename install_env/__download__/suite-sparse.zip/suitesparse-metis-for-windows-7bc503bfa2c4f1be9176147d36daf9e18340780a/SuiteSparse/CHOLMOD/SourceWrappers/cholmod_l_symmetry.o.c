#define DLONG
#include <../MatrixOps/cholmod_symmetry.c>
