#define DLONG
#include <../Core/cholmod_add.c>
