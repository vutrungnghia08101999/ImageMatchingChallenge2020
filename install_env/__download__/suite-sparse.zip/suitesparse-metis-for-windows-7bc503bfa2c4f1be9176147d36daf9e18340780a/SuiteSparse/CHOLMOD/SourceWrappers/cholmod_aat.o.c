#include <../Core/cholmod_aat.c>
