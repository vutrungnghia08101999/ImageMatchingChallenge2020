#define DLONG
#include <../Check/cholmod_check.c>
