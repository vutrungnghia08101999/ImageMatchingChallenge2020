#include <../Source/amd_global.c>
