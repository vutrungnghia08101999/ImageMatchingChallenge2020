#define DLONG
#include <../Source/amd_post_tree.c>
