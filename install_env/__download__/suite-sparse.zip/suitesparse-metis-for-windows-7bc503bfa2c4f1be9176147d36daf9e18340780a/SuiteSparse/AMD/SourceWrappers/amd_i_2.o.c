#define DINT
#include <../Source/amd_2.c>
