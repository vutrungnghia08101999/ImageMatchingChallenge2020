#define DLONG
#include <../Source/amd_2.c>
