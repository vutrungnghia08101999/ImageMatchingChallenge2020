#define DINT
#include <../Source/amd_defaults.c>
