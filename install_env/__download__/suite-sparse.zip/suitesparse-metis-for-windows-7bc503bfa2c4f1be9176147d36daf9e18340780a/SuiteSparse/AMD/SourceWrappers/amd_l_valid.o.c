#define DLONG
#include <../Source/amd_valid.c>
