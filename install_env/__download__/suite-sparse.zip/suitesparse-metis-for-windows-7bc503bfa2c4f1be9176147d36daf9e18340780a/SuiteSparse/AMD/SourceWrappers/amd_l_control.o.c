#define DLONG
#include <../Source/amd_control.c>
