#define DINT
#include <../Source/amd_postorder.c>
