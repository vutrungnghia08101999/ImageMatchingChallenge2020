#define DINT
#include <../Source/amd_order.c>
