#define DLONG
#include <../Source/amd_aat.c>
