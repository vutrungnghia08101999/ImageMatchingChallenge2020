#define DINT
#include <../Source/amd_info.c>
