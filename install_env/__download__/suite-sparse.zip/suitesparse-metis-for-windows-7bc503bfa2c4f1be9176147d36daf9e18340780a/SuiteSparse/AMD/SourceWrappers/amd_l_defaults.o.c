#define DLONG
#include <../Source/amd_defaults.c>
