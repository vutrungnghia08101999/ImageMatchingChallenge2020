#define DLONG
#include <../Source/amd_order.c>
