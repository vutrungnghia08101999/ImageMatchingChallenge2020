#define DINT
#include <../Source/amd_control.c>
