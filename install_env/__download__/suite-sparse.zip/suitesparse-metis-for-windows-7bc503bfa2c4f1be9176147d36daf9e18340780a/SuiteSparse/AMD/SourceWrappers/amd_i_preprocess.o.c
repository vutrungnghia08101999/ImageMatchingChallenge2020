#define DINT
#include <../Source/amd_preprocess.c>
