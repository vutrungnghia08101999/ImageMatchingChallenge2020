#define DLONG
#include <../Source/amd_preprocess.c>
