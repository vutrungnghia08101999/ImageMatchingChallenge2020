#define DINT
#include <../Source/amd_aat.c>
