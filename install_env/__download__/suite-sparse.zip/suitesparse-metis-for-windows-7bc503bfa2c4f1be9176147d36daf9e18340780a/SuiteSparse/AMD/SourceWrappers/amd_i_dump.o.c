#define DINT
#include <../Source/amd_dump.c>
