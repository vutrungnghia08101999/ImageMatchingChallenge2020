#define DLONG
#include <../Source/amd_postorder.c>
