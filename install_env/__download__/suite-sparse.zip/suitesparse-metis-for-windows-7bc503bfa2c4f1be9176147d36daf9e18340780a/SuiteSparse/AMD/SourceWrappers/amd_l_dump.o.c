#define DLONG
#include <../Source/amd_dump.c>
