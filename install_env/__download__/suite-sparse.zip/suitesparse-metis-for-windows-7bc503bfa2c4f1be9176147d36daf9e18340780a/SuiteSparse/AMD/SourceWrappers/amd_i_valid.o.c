#define DINT
#include <../Source/amd_valid.c>
