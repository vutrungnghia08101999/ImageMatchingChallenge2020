#define DINT
#include <../Source/camd_defaults.c>
