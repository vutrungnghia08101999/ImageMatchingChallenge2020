#define DINT
#include <../Source/camd_info.c>
