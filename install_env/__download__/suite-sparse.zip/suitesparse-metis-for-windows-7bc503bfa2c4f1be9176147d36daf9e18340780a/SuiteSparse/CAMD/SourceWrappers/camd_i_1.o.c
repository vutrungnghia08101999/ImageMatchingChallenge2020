#define DINT
#include <../Source/camd_1.c>
