#define DLONG
#include <../Source/camd_postorder.c>
