#define DLONG
#include <../Source/camd_control.c>
