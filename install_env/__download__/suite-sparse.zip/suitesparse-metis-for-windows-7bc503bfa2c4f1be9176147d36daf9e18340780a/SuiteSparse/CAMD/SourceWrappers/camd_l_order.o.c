#define DLONG
#include <../Source/camd_order.c>
