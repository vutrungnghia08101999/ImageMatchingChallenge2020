#define DLONG
#include <../Source/camd_preprocess.c>
