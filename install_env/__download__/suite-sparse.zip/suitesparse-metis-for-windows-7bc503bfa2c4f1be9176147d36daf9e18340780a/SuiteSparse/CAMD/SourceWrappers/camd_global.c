#include <../Source/camd_global.c>
