#define DINT
#include <../Source/camd_control.c>
