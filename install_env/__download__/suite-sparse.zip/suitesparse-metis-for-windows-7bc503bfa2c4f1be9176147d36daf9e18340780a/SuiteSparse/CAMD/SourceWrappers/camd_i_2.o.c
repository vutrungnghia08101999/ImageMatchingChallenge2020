#define DINT
#include <../Source/camd_2.c>
