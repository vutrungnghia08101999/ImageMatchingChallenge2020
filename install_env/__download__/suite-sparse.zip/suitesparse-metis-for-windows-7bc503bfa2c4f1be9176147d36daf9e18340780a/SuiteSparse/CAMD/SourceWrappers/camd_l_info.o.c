#define DLONG
#include <../Source/camd_info.c>
