#define DINT
#include <../Source/camd_dump.c>
