#define DLONG
#include <../Source/camd_dump.c>
