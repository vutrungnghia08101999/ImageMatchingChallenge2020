#define DINT
#include <../Source/camd_valid.c>
