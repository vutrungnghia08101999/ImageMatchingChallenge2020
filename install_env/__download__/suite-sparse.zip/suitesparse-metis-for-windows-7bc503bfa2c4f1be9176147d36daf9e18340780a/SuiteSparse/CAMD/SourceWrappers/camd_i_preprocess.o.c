#define DINT
#include <../Source/camd_preprocess.c>
