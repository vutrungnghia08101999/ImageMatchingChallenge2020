#define DLONG
#include <../Source/camd_defaults.c>
