#define DLONG
#include <../Source/camd_1.c>
