#define DLONG
#include <../Source/camd_2.c>
