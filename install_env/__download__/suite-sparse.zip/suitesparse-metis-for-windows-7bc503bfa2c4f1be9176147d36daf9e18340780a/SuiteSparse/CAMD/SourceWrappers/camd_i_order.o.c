#define DINT
#include <../Source/camd_order.c>
