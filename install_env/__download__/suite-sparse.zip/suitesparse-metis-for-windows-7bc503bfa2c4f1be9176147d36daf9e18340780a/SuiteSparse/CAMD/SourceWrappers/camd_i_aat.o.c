#define DINT
#include <../Source/camd_aat.c>
