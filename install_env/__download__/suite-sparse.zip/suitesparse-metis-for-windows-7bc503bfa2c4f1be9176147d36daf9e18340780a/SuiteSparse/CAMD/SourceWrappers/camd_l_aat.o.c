#define DLONG
#include <../Source/camd_aat.c>
