#define DINT
#include <../Source/camd_postorder.c>
