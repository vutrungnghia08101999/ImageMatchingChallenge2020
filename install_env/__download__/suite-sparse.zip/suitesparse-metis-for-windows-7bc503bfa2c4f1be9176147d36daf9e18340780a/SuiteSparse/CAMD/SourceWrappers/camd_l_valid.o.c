#define DLONG
#include <../Source/camd_valid.c>
