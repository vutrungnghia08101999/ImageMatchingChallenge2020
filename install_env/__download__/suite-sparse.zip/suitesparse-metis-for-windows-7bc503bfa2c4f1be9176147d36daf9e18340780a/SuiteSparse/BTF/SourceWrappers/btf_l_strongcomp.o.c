#define DLONG
#include <../Source/btf_strongcomp.c>
