#include <../Source/ccolamd.c>
