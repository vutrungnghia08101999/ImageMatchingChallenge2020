#define DLONG
#include <../Source/ccolamd.c>
