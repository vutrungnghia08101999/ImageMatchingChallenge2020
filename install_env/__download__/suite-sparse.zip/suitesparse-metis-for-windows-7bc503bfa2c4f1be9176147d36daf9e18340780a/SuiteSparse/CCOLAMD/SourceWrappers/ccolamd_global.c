#include <../Source/ccolamd_global.c>
